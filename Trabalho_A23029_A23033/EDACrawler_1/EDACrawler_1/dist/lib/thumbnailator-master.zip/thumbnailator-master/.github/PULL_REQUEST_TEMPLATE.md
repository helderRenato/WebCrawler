**Hello! Thank you for your interest in contributing to Thumbnailator!**

Unfortunately, I'm not accepting pull requests at this moment.

Contributions in the form of bugs reports or feature enhancements through
[issues](https://github.com/coobird/thumbnailator/issues) are appreciated.
